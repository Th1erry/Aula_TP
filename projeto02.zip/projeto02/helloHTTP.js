// importar bviblioteca com protocolo http e url
const http = require('http');
const url = require('url');
const fs = require('fs');

function readFile(response, file){
    fs.readFile(file, function (err, data){
        response.end(data);
    });
}
//criar função para trbalhar no servidor
var callback = function (request,response){

    
    var parts = url.parse(request.url);
    var path = parts.path;

    if(parts.path == "/"){
        response.writeHead(200, {"Content.type": "text/html"});
        response.end("sitebatata.html")
        
    }else if (parts.path == "/rota1"){
        response.writeHead(200, {"Content.type": "application/json"});
        readFile(response, "arquivo.json");
    }else if (parts.path == "/rota2"){
        response.writeHead(200, {"Content.type": "application/pdf"});
        readFile(response, "arquivo2.pdf");
    }
    else if (parts.path == "/rota3"){
        response.writeHead(200, {"Content.type": "application/zip"});
        readFile(response, "arquivo3.zip");
    }
    else if (parts.path == "/rota4"){
        response.writeHead(200, {"Content.type": "imagem/png"});
        readFile(response, "arquivo4.png");
    }else if(parts.path == "/rota5"){
        response.writeHead(200, {"Content.type": "text/html"});
        readFile(response, "SiteUnicsul.html");
    }else if(parts.path == "/rota6"){
        response.writeHead(200, {"Content.type": "text/html"});
        readFile(response, "Geradores.html");
    }else{
        response.writeHead(200, {"Content.type": "text/html"});
        readFile(response, "site404.html");
    }


}
// criar servidor
var server = http.createServer(callback);
// configurar a porta que sera utilizada
server.listen(3000);
// mostrar mensagem no terminal para indicar status do web server
console.log("[SERVER - OK]... Servidor montado em http://localhost:3000")
